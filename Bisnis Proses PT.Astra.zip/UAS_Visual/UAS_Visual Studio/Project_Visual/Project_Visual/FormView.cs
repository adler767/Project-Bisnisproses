﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Visual
{
    public partial class FormView : Form
    {
        public FormView()
        {
            InitializeComponent();
        }
        public string parameter = "";
        private void FormView_Load(object sender, EventArgs e)
        {
            DataClasses1DataContext data = new DataClasses1DataContext();
            var dataa = (from a in data.tbl_Karyawans select a);
            dataGridView1.DataSource = dataa;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            parameter = dataGridView1.CurrentRow.Cells["KodeKaryawan"].Value.ToString();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            DataClasses1DataContext data = new DataClasses1DataContext();
            var dataa = (from a in data.tbl_Karyawans where a.Nama.Contains(textBox1.Text) select a);
            dataGridView1.DataSource = dataa;
        }
    }
}
