﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Visual
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CrystalReport1 vcr = new CrystalReport1();
            crystalReportViewer1.SelectionFormula = "{vw_cetaktransaksi.IdPelanggan} ='" + comboBox1.Text + "'";
            crystalReportViewer1.ReportSource = vcr;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CrystalReport1 vcr = new CrystalReport1();
            crystalReportViewer1.SelectionFormula = "{vw_cetaktransaksi.Namabarang} ='" + textBox1.Text + "'";
            crystalReportViewer1.ReportSource = vcr;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CrystalReport1 vcr = new CrystalReport1();
            crystalReportViewer1.SelectionFormula = "{vw_cetaktransaksi.IdPelanggan} ='" + comboBox1.Text + "'" + "and {vw_cetaktransaksi.NamaBarang} ='" + textBox1.Text + "'";
            crystalReportViewer1.ReportSource = vcr;
        }
    }
}
