﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Text;

namespace Project_Visual.GUI
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        static void Tulis(string kata)
        {
            FileStream fs = new FileStream("C:\\Users\\asus\\OneDrive\\Dokumen\\SEMESTER 2\\Human and Computer Interaction\\UAS_Visual\\UAS_Visual Studio\\Project_Visual\\Project_Visual\\History.txt", FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(kata);
            sw.Close();
            fs.Close();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection koneksi = new SqlConnection("Data Source=LAPTOP-V4IJR5LS\\SQLEXPRESS;Initial Catalog=db_penjualan;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("select count (*) from Login where NamaUser = '" + textBox1.Text + "' and Password = '" + textBox2.Text + "'", koneksi);
            Tulis(textBox1.Text);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
                this.Hide();
                Menu_Utama panggil = new Menu_Utama();
                panggil.Show();
                DateTime now = DateTime.Now;
                Tulis(textBox1.Text + "\n" + now + "\n--------------------------------------------------");

            }
            else
            {
                MessageBox.Show("Mohon isi Username dan Password dengan benar !", "Perhatian", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
