﻿namespace Project_Visual.GUI
{
    partial class FormTransaksi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView_transaksi = new System.Windows.Forms.DataGridView();
            this.label_totalseluruh = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox_transaksi = new System.Windows.Forms.GroupBox();
            this.button_simpan = new System.Windows.Forms.Button();
            this.button_baru = new System.Windows.Forms.Button();
            this.button_minus = new System.Windows.Forms.Button();
            this.button_plus = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox_jumlah = new System.Windows.Forms.TextBox();
            this.button_caribarang = new System.Windows.Forms.Button();
            this.textBox_namabarang = new System.Windows.Forms.TextBox();
            this.textBox_hargabarang = new System.Windows.Forms.TextBox();
            this.textBox_kodebarang = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_caripelanggan = new System.Windows.Forms.Button();
            this.textBox_namapelanggan = new System.Windows.Forms.TextBox();
            this.textBox_idpelanggan = new System.Windows.Forms.TextBox();
            this.dateTimePicker_kwitansi = new System.Windows.Forms.DateTimePicker();
            this.textBox_kwitansi = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_transaksi)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView_transaksi
            // 
            this.dataGridView_transaksi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_transaksi.Location = new System.Drawing.Point(458, 58);
            this.dataGridView_transaksi.Name = "dataGridView_transaksi";
            this.dataGridView_transaksi.RowHeadersWidth = 51;
            this.dataGridView_transaksi.RowTemplate.Height = 24;
            this.dataGridView_transaksi.Size = new System.Drawing.Size(731, 430);
            this.dataGridView_transaksi.TabIndex = 18;
            this.dataGridView_transaksi.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_transaksi_CellDoubleClick);
            // 
            // label_totalseluruh
            // 
            this.label_totalseluruh.AutoSize = true;
            this.label_totalseluruh.Location = new System.Drawing.Point(679, 498);
            this.label_totalseluruh.Name = "label_totalseluruh";
            this.label_totalseluruh.Size = new System.Drawing.Size(16, 17);
            this.label_totalseluruh.TabIndex = 25;
            this.label_totalseluruh.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(506, 496);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 17);
            this.label9.TabIndex = 24;
            this.label9.Text = "Total Seluruh Rp.";
            // 
            // groupBox_transaksi
            // 
            this.groupBox_transaksi.Location = new System.Drawing.Point(458, 26);
            this.groupBox_transaksi.Name = "groupBox_transaksi";
            this.groupBox_transaksi.Size = new System.Drawing.Size(737, 469);
            this.groupBox_transaksi.TabIndex = 23;
            this.groupBox_transaksi.TabStop = false;
            this.groupBox_transaksi.Text = ":: Data Transaksi ::";
            // 
            // button_simpan
            // 
            this.button_simpan.Location = new System.Drawing.Point(265, 494);
            this.button_simpan.Name = "button_simpan";
            this.button_simpan.Size = new System.Drawing.Size(123, 36);
            this.button_simpan.TabIndex = 22;
            this.button_simpan.Text = "Simpan";
            this.button_simpan.UseVisualStyleBackColor = true;
            this.button_simpan.Click += new System.EventHandler(this.button_simpan_Click);
            // 
            // button_baru
            // 
            this.button_baru.Location = new System.Drawing.Point(26, 494);
            this.button_baru.Name = "button_baru";
            this.button_baru.Size = new System.Drawing.Size(131, 36);
            this.button_baru.TabIndex = 21;
            this.button_baru.Text = "Baru";
            this.button_baru.UseVisualStyleBackColor = true;
            this.button_baru.Click += new System.EventHandler(this.button_baru_Click);
            // 
            // button_minus
            // 
            this.button_minus.Location = new System.Drawing.Point(334, 165);
            this.button_minus.Name = "button_minus";
            this.button_minus.Size = new System.Drawing.Size(41, 36);
            this.button_minus.TabIndex = 12;
            this.button_minus.Text = "-";
            this.button_minus.UseVisualStyleBackColor = true;
            this.button_minus.Click += new System.EventHandler(this.button_minus_Click);
            // 
            // button_plus
            // 
            this.button_plus.Location = new System.Drawing.Point(262, 165);
            this.button_plus.Name = "button_plus";
            this.button_plus.Size = new System.Drawing.Size(41, 36);
            this.button_plus.TabIndex = 11;
            this.button_plus.Text = "+";
            this.button_plus.UseVisualStyleBackColor = true;
            this.button_plus.Click += new System.EventHandler(this.button_plus_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.groupBox2.Controls.Add(this.button_minus);
            this.groupBox2.Controls.Add(this.button_plus);
            this.groupBox2.Controls.Add(this.textBox_jumlah);
            this.groupBox2.Controls.Add(this.button_caribarang);
            this.groupBox2.Controls.Add(this.textBox_namabarang);
            this.groupBox2.Controls.Add(this.textBox_hargabarang);
            this.groupBox2.Controls.Add(this.textBox_kodebarang);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(4, 250);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(426, 238);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = ":: Ambil Barang  ::";
            // 
            // textBox_jumlah
            // 
            this.textBox_jumlah.Location = new System.Drawing.Point(244, 136);
            this.textBox_jumlah.Multiline = true;
            this.textBox_jumlah.Name = "textBox_jumlah";
            this.textBox_jumlah.Size = new System.Drawing.Size(131, 23);
            this.textBox_jumlah.TabIndex = 10;
            // 
            // button_caribarang
            // 
            this.button_caribarang.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_caribarang.Location = new System.Drawing.Point(159, 63);
            this.button_caribarang.Name = "button_caribarang";
            this.button_caribarang.Size = new System.Drawing.Size(79, 23);
            this.button_caribarang.TabIndex = 2;
            this.button_caribarang.Text = "Search";
            this.button_caribarang.UseVisualStyleBackColor = true;
            this.button_caribarang.Click += new System.EventHandler(this.button_caribarang_Click_1);
            // 
            // textBox_namabarang
            // 
            this.textBox_namabarang.Location = new System.Drawing.Point(244, 63);
            this.textBox_namabarang.Multiline = true;
            this.textBox_namabarang.Name = "textBox_namabarang";
            this.textBox_namabarang.Size = new System.Drawing.Size(140, 41);
            this.textBox_namabarang.TabIndex = 8;
            // 
            // textBox_hargabarang
            // 
            this.textBox_hargabarang.Location = new System.Drawing.Point(22, 136);
            this.textBox_hargabarang.Multiline = true;
            this.textBox_hargabarang.Name = "textBox_hargabarang";
            this.textBox_hargabarang.Size = new System.Drawing.Size(131, 23);
            this.textBox_hargabarang.TabIndex = 9;
            // 
            // textBox_kodebarang
            // 
            this.textBox_kodebarang.Location = new System.Drawing.Point(22, 63);
            this.textBox_kodebarang.Multiline = true;
            this.textBox_kodebarang.Name = "textBox_kodebarang";
            this.textBox_kodebarang.Size = new System.Drawing.Size(131, 41);
            this.textBox_kodebarang.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(249, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "Nama Barang";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(241, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Jumlah";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(19, 107);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 16);
            this.label7.TabIndex = 4;
            this.label7.Text = "Harga Barang";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(19, 38);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 16);
            this.label8.TabIndex = 3;
            this.label8.Text = "Kode Barang";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_caripelanggan);
            this.groupBox1.Controls.Add(this.textBox_namapelanggan);
            this.groupBox1.Controls.Add(this.textBox_idpelanggan);
            this.groupBox1.Controls.Add(this.dateTimePicker_kwitansi);
            this.groupBox1.Controls.Add(this.textBox_kwitansi);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Location = new System.Drawing.Point(4, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(426, 238);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = ":: Form Transaksi Penjualan ::";
            // 
            // button_caripelanggan
            // 
            this.button_caripelanggan.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_caripelanggan.Location = new System.Drawing.Point(146, 193);
            this.button_caripelanggan.Name = "button_caripelanggan";
            this.button_caripelanggan.Size = new System.Drawing.Size(72, 24);
            this.button_caripelanggan.TabIndex = 2;
            this.button_caripelanggan.Text = "Search";
            this.button_caripelanggan.UseVisualStyleBackColor = true;
            this.button_caripelanggan.Click += new System.EventHandler(this.button_caripelanggan_Click);
            // 
            // textBox_namapelanggan
            // 
            this.textBox_namapelanggan.Location = new System.Drawing.Point(224, 194);
            this.textBox_namapelanggan.Multiline = true;
            this.textBox_namapelanggan.Name = "textBox_namapelanggan";
            this.textBox_namapelanggan.Size = new System.Drawing.Size(140, 38);
            this.textBox_namapelanggan.TabIndex = 8;
            // 
            // textBox_idpelanggan
            // 
            this.textBox_idpelanggan.Location = new System.Drawing.Point(9, 193);
            this.textBox_idpelanggan.Multiline = true;
            this.textBox_idpelanggan.Name = "textBox_idpelanggan";
            this.textBox_idpelanggan.Size = new System.Drawing.Size(131, 39);
            this.textBox_idpelanggan.TabIndex = 9;
            // 
            // dateTimePicker_kwitansi
            // 
            this.dateTimePicker_kwitansi.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker_kwitansi.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_kwitansi.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_kwitansi.Location = new System.Drawing.Point(244, 80);
            this.dateTimePicker_kwitansi.Name = "dateTimePicker_kwitansi";
            this.dateTimePicker_kwitansi.Size = new System.Drawing.Size(176, 25);
            this.dateTimePicker_kwitansi.TabIndex = 8;
            // 
            // textBox_kwitansi
            // 
            this.textBox_kwitansi.Location = new System.Drawing.Point(244, 38);
            this.textBox_kwitansi.Multiline = true;
            this.textBox_kwitansi.Name = "textBox_kwitansi";
            this.textBox_kwitansi.Size = new System.Drawing.Size(176, 21);
            this.textBox_kwitansi.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(155, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Tgl Kwitansi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(227, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Nama Pelanggan";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 163);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "ID Pelanggan";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(158, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "No Kwitansi";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(6, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(114, 116);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // FormTransaksi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1223, 579);
            this.Controls.Add(this.dataGridView_transaksi);
            this.Controls.Add(this.label_totalseluruh);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox_transaksi);
            this.Controls.Add(this.button_simpan);
            this.Controls.Add(this.button_baru);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormTransaksi";
            this.Text = "FormTransaksi";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_transaksi)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_totalseluruh;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox_transaksi;
        private System.Windows.Forms.Button button_simpan;
        private System.Windows.Forms.Button button_baru;
        private System.Windows.Forms.Button button_minus;
        private System.Windows.Forms.Button button_plus;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox_jumlah;
        private System.Windows.Forms.Button button_caribarang;
        private System.Windows.Forms.TextBox textBox_namabarang;
        private System.Windows.Forms.TextBox textBox_hargabarang;
        private System.Windows.Forms.TextBox textBox_kodebarang;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_caripelanggan;
        private System.Windows.Forms.TextBox textBox_namapelanggan;
        private System.Windows.Forms.TextBox textBox_idpelanggan;
        private System.Windows.Forms.DateTimePicker dateTimePicker_kwitansi;
        private System.Windows.Forms.TextBox textBox_kwitansi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView_transaksi;
    }
}