﻿namespace Project_Visual.GUI
{
    partial class DialogPelanggan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView_pelanggan = new System.Windows.Forms.DataGridView();
            this.textBox_cari = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox_obat = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_pelanggan)).BeginInit();
            this.groupBox_obat.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView_pelanggan
            // 
            this.dataGridView_pelanggan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_pelanggan.Location = new System.Drawing.Point(0, 78);
            this.dataGridView_pelanggan.Name = "dataGridView_pelanggan";
            this.dataGridView_pelanggan.RowHeadersWidth = 51;
            this.dataGridView_pelanggan.RowTemplate.Height = 24;
            this.dataGridView_pelanggan.Size = new System.Drawing.Size(762, 283);
            this.dataGridView_pelanggan.TabIndex = 2;
            this.dataGridView_pelanggan.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_pelanggan_CellDoubleClick);
            // 
            // textBox_cari
            // 
            this.textBox_cari.Location = new System.Drawing.Point(249, 41);
            this.textBox_cari.Name = "textBox_cari";
            this.textBox_cari.Size = new System.Drawing.Size(358, 22);
            this.textBox_cari.TabIndex = 1;
            this.textBox_cari.TextChanged += new System.EventHandler(this.textBox_cari_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cari Pelanggan (ID/Nama)";
            // 
            // groupBox_obat
            // 
            this.groupBox_obat.Controls.Add(this.dataGridView_pelanggan);
            this.groupBox_obat.Controls.Add(this.textBox_cari);
            this.groupBox_obat.Controls.Add(this.label1);
            this.groupBox_obat.Location = new System.Drawing.Point(19, 45);
            this.groupBox_obat.Name = "groupBox_obat";
            this.groupBox_obat.Size = new System.Drawing.Size(762, 361);
            this.groupBox_obat.TabIndex = 2;
            this.groupBox_obat.TabStop = false;
            this.groupBox_obat.Text = ":: Data Pelanggan ::";
            this.groupBox_obat.Enter += new System.EventHandler(this.groupBox_obat_Enter);
            // 
            // DialogPelanggan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox_obat);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DialogPelanggan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DialogPelanggan";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_pelanggan)).EndInit();
            this.groupBox_obat.ResumeLayout(false);
            this.groupBox_obat.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView_pelanggan;
        private System.Windows.Forms.TextBox textBox_cari;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox_obat;
    }
}