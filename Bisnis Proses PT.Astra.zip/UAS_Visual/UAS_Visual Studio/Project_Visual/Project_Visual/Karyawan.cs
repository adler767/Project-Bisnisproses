﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Visual
{
    public partial class Karyawan : Form
    {
        public Karyawan()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext data = new DataClasses1DataContext();
            tbl_Karyawan tbl = new tbl_Karyawan
            {
                IdKaryawan = textBox_id.Text,
                Nama = textBox_nama.Text,
                Alamat = textBox_alamat.Text,
                NoTelp = textBox_telp.Text,
            };
            data.tbl_Karyawans.InsertOnSubmit(tbl);
            try
            {
                data.SubmitChanges();
                MessageBox.Show("Succeed");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext data = new DataClasses1DataContext();
            var update = (from a in data.tbl_Karyawans where a.IdKaryawan == textBox_id.Text select a).Single();

            update.Nama = textBox_nama.Text;
            update.Alamat = textBox_alamat.Text;
            update.NoTelp = textBox_telp.Text;

            try
            {
                data.SubmitChanges();
                MessageBox.Show("Succeed");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DataClasses1DataContext data = new DataClasses1DataContext();
            var delete = (from a in data.tbl_Karyawans where a.IdKaryawan == textBox_id.Text select a).Single();

            data.tbl_Karyawans.DeleteOnSubmit(delete);
            try
            {
                data.SubmitChanges();
                MessageBox.Show("Succeed");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormView fw = new FormView();
            fw.ShowDialog();
            textBox_id.Text = fw.parameter;
        }
    }
}
