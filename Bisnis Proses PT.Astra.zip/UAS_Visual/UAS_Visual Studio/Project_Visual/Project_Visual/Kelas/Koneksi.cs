﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Project_Visual.Kelas
{
    class Koneksi
    {
        public SqlConnection GetConn()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source = LAPTOP-V4IJR5LS\\SQLEXPRESS; Initial Catalog=db_penjualan; Integrated Security=True";
            return conn;
        }
    }
}
